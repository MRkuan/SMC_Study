


                          C Example 4


Simplistic, non-graphical simulation of a stoplight. Demonstrates
how to use state machines to handle external events (in this case
timeouts).


+ Building
----------

NOTE: Smc.jar must be built and installed.

Unix & Windows (MinGW):
    $ make traffic


+ Executing
-----------

Unix & Windows:

    $ traffic
