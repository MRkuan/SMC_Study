statemap
========

INSTALLATION

To install this module, type the following:

   python setup.py install


DOCUMENTATION

To generate the file statemap.html, type the following:

   pydoc -w statemap
