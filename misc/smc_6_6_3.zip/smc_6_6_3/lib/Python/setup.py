from distutils.core import setup

setup(name="statemap",
           version="0.03",
           description="SM runtime",
           author="Francois Perrad",
           author_email="francois.perrad@gadz.org",
           url="http://smc.sourceforge.net",
           license="MPL 1.1",
           py_modules=['statemap'],
)

